export interface ICoordinate2D {
    x: number;
    y: number;
}
